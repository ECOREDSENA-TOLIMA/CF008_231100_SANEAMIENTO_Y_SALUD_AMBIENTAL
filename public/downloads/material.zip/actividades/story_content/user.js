function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6Zz17fNpZ4x":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}


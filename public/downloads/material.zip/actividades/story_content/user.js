function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5aRhVE7bTsA":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

